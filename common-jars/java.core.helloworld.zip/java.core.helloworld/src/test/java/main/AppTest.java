package main;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class AppTest 
    extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public AppTest( String testName )
    {
        super( testName );
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( AppTest.class );
    }

    /**
     * test simple hello world
     */
    public void testSimpleHelloWorld()
    {
    	final String message = "Hello World";
    	HelloWorld obj = new HelloWorld();
    	obj.setMessage(message);
    	assertEquals(message, obj.getMessage());
    }
    /**
     * test description annotation value
     * @see EnumStandardMessages
     * @see EnumHelper
     */
    public void testDescriptionAnnotation()
    {
    	final EnumStandardMessages code = EnumStandardMessages.ENGLISH;
    	final String desc = EnumHelper.getDescAnnotationValue(EnumStandardMessages.class, code.name());
    	final String message = "Hello World";
    	assertEquals(desc, message);
    }

    /**
     * test standard english hello world
     * @see EnumStandardMessages
     * @see EnumHelper
     */
    public void testEnglishHelloWorld()
    {
    	final EnumStandardMessages code = EnumStandardMessages.ENGLISH;
    	final String message = EnumHelper.getDescAnnotationValue(EnumStandardMessages.class, code.name());
    	HelloWorld obj = new HelloWorld();
    	obj.setStandardMessage(code);
    	assertEquals(message, obj.getMessage());
    }
    /**
     * test standard french hello world
     * @see EnumStandardMessages
     * @see EnumHelper
     */
    public void testFrenchHelloWorld()
    {
    	final EnumStandardMessages code = EnumStandardMessages.FRENCH;
    	final String message = EnumHelper.getDescAnnotationValue(EnumStandardMessages.class, code.name());
    	HelloWorld obj = new HelloWorld();
    	obj.setStandardMessage(code);
    	assertEquals(message, obj.getMessage());
    }
    /**
     * test standard spanish hello world
     * @see EnumStandardMessages
     * @see EnumHelper
     */
    public void testSpanishHelloWorld()
    {
    	final EnumStandardMessages code = EnumStandardMessages.SPANISH;
    	final String message = EnumHelper.getDescAnnotationValue(EnumStandardMessages.class, code.name());
    	HelloWorld obj = new HelloWorld();
    	obj.setStandardMessage(code);
    	assertEquals(message, obj.getMessage());
    }
    /**
     * test standard german hello world
     * @see EnumStandardMessages
     * @see EnumHelper
     */
    public void testGermanHelloWorld()
    {
    	final EnumStandardMessages code = EnumStandardMessages.GERMAN;
    	final String message = EnumHelper.getDescAnnotationValue(EnumStandardMessages.class, code.name());
    	HelloWorld obj = new HelloWorld();
    	obj.setStandardMessage(code);
    	assertEquals(message, obj.getMessage());
    }
}
