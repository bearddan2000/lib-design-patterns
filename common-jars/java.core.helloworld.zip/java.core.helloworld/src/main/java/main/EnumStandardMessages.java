package main;

import jdk.jfr.Description;

/***
 * Hello World in 4 languages
 * @author Daniel Beard
 *
 */
public enum EnumStandardMessages {
	@Description("Hello World") ENGLISH
	, @Description("Salute monde") FRENCH
	, @Description("Hola mundo") SPANISH
	, @Description("Tous das Weild") GERMAN
}
