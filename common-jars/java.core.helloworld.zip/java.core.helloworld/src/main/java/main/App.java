package main;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	HelloWorld obj = new HelloWorld();
    	obj.setMessage("Hello World");
        System.out.println( obj.getMessage() );
    }
}
