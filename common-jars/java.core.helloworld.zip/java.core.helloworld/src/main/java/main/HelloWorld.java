package main;

/**
 * Simple hello world
 * @author Daniel Beard
 * @since 10/16/2019
 *
 */
public class HelloWorld {
	String mMessage = null;

	/**
	 * @return the mMessage
	 */
	public String getMessage() {
		return mMessage;
	}

	/**
	 * @param message the mMessage to set
	 */
	public void setMessage(String message) {
		this.mMessage = message;
	}
	/**
	 * @param message the mMessage to set
	 */
	public void setStandardMessage(EnumStandardMessages message) {
		this.mMessage = EnumHelper.getDescAnnotationValue(EnumStandardMessages.class, message.name());
	}
}
