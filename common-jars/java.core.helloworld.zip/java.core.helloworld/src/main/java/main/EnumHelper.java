package main;

import java.lang.annotation.Annotation;
/***
 * Helper class for extracting values from annotations
 * @author Daniel Beard
 *
 */
public class EnumHelper {
	/***
	 * Extract value from Description
	 * @param <T> any object
	 * @param enumClass class type
	 * @param fieldName field of enum to look at
	 * @return Description value
	 */
	public static <T> String getDescAnnotationValue(Class<T> enumClass, String fieldName)
	{		
		jdk.jfr.Description returnValue = (jdk.jfr.Description) getFirstAnnotation(enumClass, fieldName);
		return returnValue.value();
	}
	private static <T> Annotation getFirstAnnotation(Class<T> enumClass, String fieldName)
	{
		Annotation[] annos = null;
		try {
			annos = enumClass.getField(fieldName).getAnnotations();
		} catch (NoSuchFieldException | SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return annos[0];
	}
}
